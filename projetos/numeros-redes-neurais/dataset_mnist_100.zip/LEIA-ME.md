# Dataset de exemplo — MNIST (100 imagens)

Este pacote contém 100 imagens de dígitos manuscritos: 10 exemplos de cada classe, de 0 a 9. As imagens foram selecionadas de forma reproduzível (`seed=42`) da divisão de teste do MNIST.

## Como usar

1. Extraia o arquivo ZIP ao lado de `numeros_redes_neurais.ipynb`.
2. Confirme que a pasta `imagens_usuario` ficou ao lado do notebook.
3. Execute todas as células do notebook.

Os nomes seguem o padrão `digito_ROTULO_mnist_NUMERO.png`, que o notebook reconhece automaticamente. O arquivo `manifesto.csv` registra o rótulo e o índice original de cada imagem.

## Limitação importante

Este conjunto serve para testar o código e fazer uma comparação com uma fonte pública independente do `sklearn digits`. Ele **não substitui** a coleta pedida no enunciado, pois as imagens não foram desenhadas pelas pessoas do grupo. Não apresente estas imagens como produção da turma.

## Fonte

- MNIST Database of Handwritten Digits, UCI Machine Learning Repository: https://archive.ics.uci.edu/dataset/683/mnist+database+of+handwritten+digits
- Arquivo distribuído para uso pelo Keras: https://storage.googleapis.com/tensorflow/tf-keras-datasets/mnist.npz
- Licença informada pelo UCI: CC BY 4.0.
